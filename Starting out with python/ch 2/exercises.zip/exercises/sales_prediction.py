#This program gets the projected amout of total sales then displays the profit that will be made

#get the projected amount of sales
sales_amount = float(input("What is the projected amount of sales?: "))

#Calculate the profit made
profit = sales_amount * 0.23

#Display the profit
print('The annual profit is: ', profit, 'percent')