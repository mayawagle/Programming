# This program tells the distance the car will trave given the amount of hours
speed = 60

#5 hours
time = 5
distance = speed * time
print(f'in 5 hours, the car will travel {distance} miles')

#8 hours
time = 8
distance = speed * time
print(f'in 8 hours, the car will travel {distance} miles')

#12 hours
time = 12
distance = speed * time
print(f'in 12 hours, the car will travel {distance} miles')