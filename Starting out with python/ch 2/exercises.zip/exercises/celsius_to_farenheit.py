#This program converts celcius to farenheit

#ask for the celcius amount
celcius = float(input('What is the temperature in celcius?: '))

#Convert the celcius to farenheit
farenheit = 9/5 * celcius + 32

#print the farenheit amount
print(f'The temperature is {farenheit} degrees farenheit')