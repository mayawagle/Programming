#This program will calculate the total price of an item
#after the sales tax of the state and county

#Get the subtotal before tax
subtotal = float(input('What is the '))